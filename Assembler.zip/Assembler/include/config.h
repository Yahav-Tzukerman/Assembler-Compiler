#ifndef CONFIG_H
#define CONFIG_H

/* Define configuration options and macros */
#define MAX_LABEL_LENGTH 32
#define MAX_LINE_LENGTH 256

#endif

