#ifndef VALIDATIONS_H
#define VALIDATIONS_H

#include "utils.h"

bool validate_macro_name(char* macroName);

#endif
