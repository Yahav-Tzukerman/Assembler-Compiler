/* Source file to implement logging functions. */
