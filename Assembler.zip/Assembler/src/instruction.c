/* Source file to implement instruction handling logic. */
