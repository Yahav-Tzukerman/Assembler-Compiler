/* A module to handle assembly directives such as .data, .string, etc. */
