/* Performs lexical analysis, breaking down lines of code into tokens.
** Provides tokens to the parser for further processing.
*/
